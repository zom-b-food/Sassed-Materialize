<footer id="bottom">
	<div class="container">
		<span class="text-muted">Place footer content here.<br/>Created by Adam @ www.ui-design-engineering.com</span>

	</div>
</footer>