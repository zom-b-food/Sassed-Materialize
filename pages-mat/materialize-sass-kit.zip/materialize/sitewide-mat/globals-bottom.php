<script src="../assets-mat/js/bootstrap-tabcollapse.min.js"></script>
<script src="../assets-mat/js/jquery.easing.min.js"></script>
<script src="../assets-mat/js/jquery.sticky.min.js"></script>
<script src="../assets-mat/js/smoothscroll.min.js"></script>
<script src="../assets-mat/js/smooth-menu.js"></script>
<script src="../assets-mat/js/jquery.stellar.min.js"></script>
<script src="../assets-mat/js/imagesloaded.js"></script>
<script src="../assets-mat/js/jquery.inview.min.js"></script>
<script src="../assets-mat/js/jquery.shuffle.min.js"></script>
<script src="../assets-mat/js/menuzord.js"></script>
<script src="../assets-mat/js/equalheight.js"></script>
<script src="../assets-mat/owl.carousel/owl.carousel.min.js"></script>
<script src="../assets-mat/flexSlider/jquery.flexslider-min.js"></script>
<script src="../assets-mat/magnific-popup/jquery.magnific-popup.min.js"></script>

